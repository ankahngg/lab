package mypack;
public class Circle {
    private float radius;

    public float getRadius() {
        return this.radius;
    }

    public void setRadius(float x) {
        this.radius = x;
    }
}
