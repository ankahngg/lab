package mypack;
public class Rectangle {
    private float chieudai;
    private float chieurong;

    public float getChieudai() {
        return this.chieudai;
    } 
    public float getChieurong() {
        return this.chieurong;
    }
    public void setChieudai(float x) {
        this.chieudai = x;
    } 
    public void setChieurong(float x) {
        this.chieurong = x;
    }
}
